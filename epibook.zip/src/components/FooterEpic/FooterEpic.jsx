
import { HomeOutline } from 'react-ionicons'
import { FolderOpenOutline } from 'react-ionicons'

const FooterEpic = ()=> {
    return (
        <footer className="blockquote-footer mt-5 d-flex align-item-center bg-dark text-white p-4">
             <div className="d-flex gap-3 align-items-center justify-content-center">
                <div className="d-flex gap-3 align-items-center justify-content-center">
                  <h2> EpicBook.com</h2>
                </div>

                <HomeOutline
                  color={'#00000'} 
                  title="Home"
                  height="40px"
                  width="40px"
                />



                <FolderOpenOutline
                  color={'#00000'} 
                  title="Sfoglia"
                  height="40px"
                  width="40px"
                />

               </div>
        
        </footer>
    )

}

export default FooterEpic