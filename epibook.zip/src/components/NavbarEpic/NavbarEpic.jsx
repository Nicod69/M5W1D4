import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';


import { navbarLinks, navbarTitle } from '../../globalData/globalData';

const NavbarEpic = ()=>{
    return (
        <>
        <Navbar expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home">{navbarTitle}</Navbar.Brand>
        
        <Navbar id="basic-navbar-nav">
          <Nav className="me-auto">
            
            {navbarLinks.map((navbarLink) =>(
              <Nav.Link href={navbarLink.href} key={navbarLink.href+navbarLink.linkDescription}>{navbarLink.linkDescription}</Nav.Link>  
            )

            )}
           
          </Nav>
        </Navbar>
      </Container>
    </Navbar>
        </>
    );
}

export default NavbarEpic