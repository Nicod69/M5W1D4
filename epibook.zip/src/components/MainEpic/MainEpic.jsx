import { Container, Row } from 'react-bootstrap'
import fantasyBook from '../../globalData/books/fantasy.json'
import CardEpic from '../CardEpic/CardEpic'


//parte centrale della pagina di Epic Book
const MainEpic = () => {
    return (
        <Container>
            <Row className="gy-2">
                {fantasyBook.map((book) => (
                    <CardEpic
                        key={book.asin}
                        title={book.title}
                        price={book.price}
                        category={book.category}
                        img={book.img}
                    />
                ))}
            </Row>
        </Container>
    )
}

export default MainEpic
