import { Col } from 'react-bootstrap'
import Button from 'react-bootstrap/Button'
import Card from 'react-bootstrap/Card'
import { eur } from '../../globalData/globalData';

// componente Card che conterrà i dati salienti del libro
const CardEpic = ({ price, category, title, img, asin }) => {
    return (
        <Col sm={12} md={4} lg={3}>
            <Card className="h-100">
                <Card.Img
                    variant="top"
                    className="h-100 w-100 object-fit-cover"
                    src={img}
                />
                <Card.Body key={asin}>
                    <Card.Title>{category}</Card.Title>
                    <Card.Text className="text-truncate">{title}</Card.Text>

                    <Card.Text>{eur.format(price)}</Card.Text>
                    <Button variant="primary">Acquista</Button>
                </Card.Body>
            </Card>
        </Col>
    )
}

export default CardEpic
