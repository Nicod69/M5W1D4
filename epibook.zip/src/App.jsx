import './globalData/globalData.js'
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import NavbarEpic from './components/NavbarEpic/NavbarEpic.jsx'
import MainEpic from './components/MainEpic/MainEpic.jsx'
import Welcome from './components/Welcome/Welcome.jsx'
import FooterEpic from './components/FooterEpic/FooterEpic.jsx'
import {LogoNodejs} from 'react-ionicons'

const App = ()=> {
  

  return (
    <>
     
      <NavbarEpic />

     <Welcome />

      <MainEpic />

      <FooterEpic />
    </>
  )
}

export default App
