//array dei link della navbar
export const navbarLinks = [
    { href: '#', linkDescription: 'Home' },
    { href: '#', linkDescription: 'About' },
    { href: '#', linkDescription: 'Browse' },
]

export const navbarTitle = "EPIC BOOK";

export const eur = new Intl.NumberFormat('en-DE', {
    style: 'currency',
    currency: 'EUR',
});